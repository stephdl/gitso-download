Licensees of Python are permitted
to redistribute mscvr71.dll, as long as they redistribute it in order
to support pythonxy.dll. The EULA says

# You also agree not to permit further distribution of the
# Redistributables by your end users except you may permit further
# redistribution of the Redistributables by your distributors to your
# end-user customers if your distributors only distribute the
# Redistributables in conjunction with, and as part of, the Licensee
# Software, you comply with all other terms of this EULA, and your
# distributors comply with all restrictions of this EULA that are
# applicable to you.

In this text, "you" is the licensee of VS 2003 (i.e. me, redistributing
msvcr71.dll as part of Python 2.5), and the "Redistributable" is
msvcr71.dll. The "Licensee Software" is "a software application product
developed by you that adds significant and primary functionality to the
Redistributables", i.e. python25.dll. 
